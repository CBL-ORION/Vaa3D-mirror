This directory contains code and parameter files used
in the WatershedSegmentation validation studies done
at the University of Utah.  See the InsightDocuments
cvs repository for complete details under 
Validation/WatershedSegmentation/.

The data used in the study is available via ftp in the Insight 
data repository.

See www.itk.org for details on accessing the InsightDocuments
and data repositories.


jc 10/16/02
